Pulpugan BMS v4.2 Android Entry prototype

Package ID: com.pulpugan.bms
Version: 4.2 (versionCode 42)

This is a basic Android WebView wrapper around app/src/main/assets/index.html.
It is a prototype for the Entry screen, not a complete implementation of every workbook tab.

Build on GitHub Actions:
1. Upload the contents of this folder (not the enclosing folder) to the root of a GitHub repository.
2. Open the repository's Actions tab.
3. Choose "Build Pulpugan BMS APK" and press "Run workflow".
4. When successful, open the run and download the artifact named Pulpugan-BMS-v4.2-debug-apk.
5. Extract the artifact ZIP to get app-debug.apk.

The GitHub Actions workflow is included at .github/workflows/build-apk.yml.
This project has not been built or tested into an APK in this environment.
